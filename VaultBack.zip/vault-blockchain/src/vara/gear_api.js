const { GearApi, GearKeyring } = require('@gear-js/api');

let api = null;
let account = null;

async function getApi() {
  if (api && api.isConnected) return api;

  api = await GearApi.create({
    providerAddress: process.env.VARA_NODE_URL,
  });

  api.provider.on('disconnected', () => {
    console.log('[Vara] Desconectado -- se reconectará en la próxima solicitud');
    api = null;
  });

  console.log(`[Vara] Conectado a ${process.env.VARA_NODE_URL}`);
  return api;
}

async function getAccount() {
  if (account) return account;
  if (!process.env.VARA_MNEMONIC) {
    throw new Error('VARA_MNEMONIC no está configurado');
  }
  // fromMnemonic es async (espera a que cargue wasm-crypto) -- sin el
  // await, account quedaba como una Promise sin resolver y firmar la
  // transacción fallaba en silencio.
  // trim() -- variables de entorno pegadas en paneles como Railway a veces
  // arrastran un espacio o salto de línea de sobra, y addFromUri() rechaza
  // el mnemonic completo con "Unable to match provided value to a secret
  // URI" en vez de ignorarlo.
  account = await GearKeyring.fromMnemonic(process.env.VARA_MNEMONIC.trim(), 'vault-blockchain');
  return account;
}

module.exports = { getApi, getAccount };
